import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { Users, UserCheck, Briefcase, Award } from 'lucide-react';
import { Candidate } from '../types';

interface DashboardProps {
  candidates: Candidate[];
  jobCount: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const Dashboard: React.FC<DashboardProps> = ({ candidates, jobCount }) => {
  
  const analyzedCandidates = candidates.filter(c => c.status === 'completed' && c.analysis);
  
  const totalScreened = analyzedCandidates.length;
  const avgScore = totalScreened > 0 
    ? Math.round(analyzedCandidates.reduce((acc, curr) => acc + (curr.analysis?.match_score || 0), 0) / totalScreened) 
    : 0;
  
  const highPotential = analyzedCandidates.filter(c => (c.analysis?.match_score || 0) > 80).length;

  // Data for Pie Chart (Recommendations)
  const recommendationData = [
    { name: 'Strong Hire', value: analyzedCandidates.filter(c => c.analysis?.recommendation === 'Strong Hire').length },
    { name: 'Hire', value: analyzedCandidates.filter(c => c.analysis?.recommendation === 'Hire').length },
    { name: 'Consider', value: analyzedCandidates.filter(c => c.analysis?.recommendation === 'Consider').length },
    { name: 'Reject', value: analyzedCandidates.filter(c => c.analysis?.recommendation === 'Reject').length },
  ].filter(d => d.value > 0);

  // Data for Bar Chart (Score Distribution)
  const scoreDistribution = [
    { name: '0-40%', count: analyzedCandidates.filter(c => (c.analysis?.match_score || 0) <= 40).length },
    { name: '41-60%', count: analyzedCandidates.filter(c => (c.analysis?.match_score || 0) > 40 && (c.analysis?.match_score || 0) <= 60).length },
    { name: '61-80%', count: analyzedCandidates.filter(c => (c.analysis?.match_score || 0) > 60 && (c.analysis?.match_score || 0) <= 80).length },
    { name: '81-100%', count: analyzedCandidates.filter(c => (c.analysis?.match_score || 0) > 80).length },
  ];

  const StatCard = ({ icon: Icon, title, value, color }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
      <div className={`p-3 rounded-full ${color} bg-opacity-10`}>
        <Icon className={`w-6 h-6 ${color.replace('bg-', 'text-')}`} />
      </div>
      <div>
        <p className="text-sm text-slate-500 font-medium">{title}</p>
        <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} title="Total Resumes" value={candidates.length} color="bg-blue-600" />
        <StatCard icon={UserCheck} title="Screened" value={totalScreened} color="bg-emerald-500" />
        <StatCard icon={Award} title="Avg Match Score" value={`${avgScore}%`} color="bg-purple-500" />
        <StatCard icon={Briefcase} title="Active Jobs" value={jobCount} color="bg-amber-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recommendation Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Recommendation Split</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={recommendationData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {recommendationData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Score Range Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Score Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoreDistribution}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: '#f1f5f9' }} />
                <Bar dataKey="count" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {analyzedCandidates.length === 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center text-blue-700">
           No resumes have been fully analyzed yet. Go to the "Screening" tab to start processing.
        </div>
      )}
    </div>
  );
};

export default Dashboard;