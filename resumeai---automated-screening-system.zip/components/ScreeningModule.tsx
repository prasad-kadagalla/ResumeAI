import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Play, X, Eye } from 'lucide-react';
import { JobDescription, Candidate, AnalysisResult } from '../types';
import { analyzeResume } from '../services/geminiService';

interface ScreeningModuleProps {
  jobs: JobDescription[];
  candidates: Candidate[];
  onAddCandidate: (candidate: Candidate) => void;
  onUpdateCandidate: (id: string, updates: Partial<Candidate>) => void;
  onViewCandidate: (candidate: Candidate) => void;
}

const ScreeningModule: React.FC<ScreeningModuleProps> = ({
  jobs,
  candidates,
  onAddCandidate,
  onUpdateCandidate,
  onViewCandidate
}) => {
  const [selectedJobId, setSelectedJobId] = useState<string>(jobs.length > 0 ? jobs[0].id : '');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedJob = jobs.find(j => j.id === selectedJobId);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        const newCandidate: Candidate = {
          id: Math.random().toString(36).substring(7),
          fileName: file.name,
          fileType: file.type,
          uploadDate: new Date().toISOString(),
          status: 'pending',
        };
        // Store base64 strictly in memory for this session
        // In a real app, you'd upload to S3/Blob storage
        (newCandidate as any).fileData = base64; 
        onAddCandidate(newCandidate);
      };
      reader.readAsDataURL(file);
    });
    
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const runAnalysis = async (candidateId: string) => {
    if (!selectedJob) return;

    const candidate = candidates.find(c => c.id === candidateId);
    if (!candidate || !(candidate as any).fileData) return;

    onUpdateCandidate(candidateId, { status: 'analyzing' });

    try {
      const result = await analyzeResume(selectedJob.requirements, (candidate as any).fileData, candidate.fileType);
      onUpdateCandidate(candidateId, { status: 'completed', analysis: result });
    } catch (error) {
      console.error(error);
      onUpdateCandidate(candidateId, { status: 'error' });
    }
  };

  const runBatchAnalysis = async () => {
    setIsProcessing(true);
    const pendingCandidates = candidates.filter(c => c.status === 'pending');
    
    // Process sequentially to avoid rate limits on demo keys, or parallel if key allows
    for (const candidate of pendingCandidates) {
      await runAnalysis(candidate.id);
    }
    setIsProcessing(false);
  };

  // Sort candidates: Completed (High Score -> Low Score), then Pending
  const sortedCandidates = [...candidates].sort((a, b) => {
    if (a.status === 'completed' && b.status === 'completed') {
      return (b.analysis?.match_score || 0) - (a.analysis?.match_score || 0);
    }
    if (a.status === 'completed') return -1;
    if (b.status === 'completed') return 1;
    return 0;
  });

  return (
    <div className="space-y-6">
      {/* Top Bar: Job Selection & Upload */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-slate-700 mb-1">Select Job Description</label>
          <select 
            value={selectedJobId} 
            onChange={(e) => setSelectedJobId(e.target.value)}
            className="w-full max-w-md border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
          >
            {jobs.map(job => (
              <option key={job.id} value={job.id}>{job.title} - {job.department}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-3">
          <input 
            type="file" 
            multiple 
            accept=".pdf,.txt,.doc,.docx,image/*" 
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileUpload}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 font-medium transition"
          >
            <Upload className="w-4 h-4" />
            Upload Resumes
          </button>
          
          <button 
            onClick={runBatchAnalysis}
            disabled={isProcessing || !selectedJob || candidates.filter(c => c.status === 'pending').length === 0}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-white transition
              ${isProcessing || !selectedJob || candidates.filter(c => c.status === 'pending').length === 0
                ? 'bg-slate-300 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700'}`}
          >
            <Play className="w-4 h-4" />
            {isProcessing ? 'Analyzing...' : 'Run NLP Analysis'}
          </button>
        </div>
      </div>

      {/* Candidates Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-slate-800">Candidates Queue</h3>
          <span className="text-sm text-slate-500">{candidates.length} candidates found</span>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-sm">
                <th className="px-6 py-4 font-medium">Candidate Name</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Match Score</th>
                <th className="px-6 py-4 font-medium">Experience</th>
                <th className="px-6 py-4 font-medium">Recommendation</th>
                <th className="px-6 py-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedCandidates.map((candidate) => (
                <tr key={candidate.id} className="hover:bg-slate-50 transition">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold">
                        {candidate.analysis?.candidate_name ? candidate.analysis.candidate_name.charAt(0) : '?'}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">
                          {candidate.analysis?.candidate_name || candidate.fileName}
                        </p>
                        <p className="text-xs text-slate-500 truncate max-w-[150px]">{candidate.analysis?.email || 'Processing...'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {candidate.status === 'pending' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">Pending</span>}
                    {candidate.status === 'analyzing' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 animate-pulse">Analyzing...</span>}
                    {candidate.status === 'completed' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Completed</span>}
                    {candidate.status === 'error' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Error</span>}
                  </td>
                  <td className="px-6 py-4">
                    {candidate.status === 'completed' && candidate.analysis ? (
                       <div className="flex items-center gap-2">
                         <div className="w-full max-w-[80px] h-2 bg-slate-200 rounded-full overflow-hidden">
                           <div 
                              className={`h-full rounded-full ${
                                candidate.analysis.match_score >= 80 ? 'bg-green-500' : 
                                candidate.analysis.match_score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                              }`} 
                              style={{ width: `${candidate.analysis.match_score}%` }}
                           />
                         </div>
                         <span className="text-sm font-bold text-slate-700">{candidate.analysis.match_score}%</span>
                       </div>
                    ) : '-'}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {candidate.status === 'completed' && candidate.analysis 
                      ? `${candidate.analysis.years_of_experience} years` 
                      : '-'}
                  </td>
                  <td className="px-6 py-4">
                    {candidate.status === 'completed' && candidate.analysis ? (
                       <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${candidate.analysis.recommendation === 'Strong Hire' ? 'bg-green-100 text-green-800' : 
                          candidate.analysis.recommendation === 'Hire' ? 'bg-blue-100 text-blue-800' :
                          candidate.analysis.recommendation === 'Consider' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'}
                       `}>
                         {candidate.analysis.recommendation}
                       </span>
                    ) : '-'}
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => onViewCandidate(candidate)}
                      disabled={candidate.status !== 'completed'}
                      className={`p-2 rounded-full hover:bg-slate-200 transition ${candidate.status !== 'completed' ? 'opacity-50 cursor-not-allowed' : 'text-blue-600'}`}
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
              {candidates.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No resumes uploaded yet.</p>
                    <p className="text-sm">Upload candidates to begin screening.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ScreeningModule;