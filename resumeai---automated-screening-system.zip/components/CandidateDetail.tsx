import React from 'react';
import { ArrowLeft, CheckCircle, XCircle, Briefcase, GraduationCap, Brain, AlertTriangle } from 'lucide-react';
import { Candidate } from '../types';

interface CandidateDetailProps {
  candidate: Candidate;
  onBack: () => void;
}

const CandidateDetail: React.FC<CandidateDetailProps> = ({ candidate, onBack }) => {
  if (!candidate.analysis) return null;
  const { analysis } = candidate;

  return (
    <div className="space-y-6 animate-fade-in">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-slate-800 transition mb-2"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Screening
      </button>

      {/* Header Card */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center text-white text-2xl font-bold">
            {analysis.candidate_name.charAt(0)}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{analysis.candidate_name}</h1>
            <p className="text-slate-500">{analysis.email} • {analysis.years_of_experience} Years Exp.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
           <div className="text-center">
             <span className="block text-sm text-slate-500 font-medium uppercase tracking-wider">Score</span>
             <span className={`text-3xl font-bold ${
               analysis.match_score >= 80 ? 'text-green-600' : 
               analysis.match_score >= 60 ? 'text-yellow-600' : 'text-red-600'
             }`}>{analysis.match_score}/100</span>
           </div>
           <div className={`px-4 py-2 rounded-lg font-bold text-sm uppercase tracking-wide
              ${analysis.recommendation === 'Strong Hire' ? 'bg-green-100 text-green-800' : 
                analysis.recommendation === 'Hire' ? 'bg-blue-100 text-blue-800' :
                analysis.recommendation === 'Consider' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'}
           `}>
             {analysis.recommendation}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Summary & Education */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-500" />
              Executive Summary
            </h3>
            <p className="text-slate-600 leading-relaxed">{analysis.summary}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-purple-500" />
              Education Evaluation
            </h3>
            <p className="text-slate-700 font-medium">{analysis.education_match}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
             <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
               <Briefcase className="w-5 h-5 text-indigo-500" />
               Skills Assessment
             </h3>
             
             <div className="mb-6">
               <h4 className="text-sm font-medium text-slate-500 mb-3 uppercase">Technical Skills (Matched)</h4>
               <div className="flex flex-wrap gap-2">
                 {analysis.technical_skills_found.map((skill, idx) => (
                   <span key={idx} className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm font-medium border border-indigo-100">
                     {skill}
                   </span>
                 ))}
               </div>
             </div>

             <div>
               <h4 className="text-sm font-medium text-slate-500 mb-3 uppercase">Soft Skills</h4>
               <div className="flex flex-wrap gap-2">
                 {analysis.soft_skills_found.map((skill, idx) => (
                   <span key={idx} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium border border-slate-200">
                     {skill}
                   </span>
                 ))}
               </div>
             </div>
          </div>
        </div>

        {/* Right Column: Missing Skills & Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 border-l-4 border-l-red-500">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Missing Critical Skills
            </h3>
            {analysis.missing_critical_skills.length > 0 ? (
              <ul className="space-y-3">
                {analysis.missing_critical_skills.map((skill, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-slate-700">
                    <XCircle className="w-4 h-4 text-red-500 mt-1 shrink-0" />
                    <span>{skill}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">No critical missing skills detected.</span>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
             <h3 className="text-lg font-semibold text-slate-800 mb-4">HR Actions</h3>
             <div className="space-y-3">
               <button className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition">
                 Shortlist Candidate
               </button>
               <button className="w-full py-2 px-4 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-medium transition">
                 Email Candidate
               </button>
               <button className="w-full py-2 px-4 bg-white border border-red-200 hover:bg-red-50 text-red-600 rounded-lg font-medium transition">
                 Reject
               </button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateDetail;