import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult } from "../types";

const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    candidate_name: { type: Type.STRING, description: "Full name of the candidate extracted from the resume." },
    email: { type: Type.STRING, description: "Email address of the candidate." },
    match_score: { type: Type.NUMBER, description: "A score from 0 to 100 indicating how well the candidate matches the job description." },
    summary: { type: Type.STRING, description: "A brief professional summary of the candidate's relevance to the role." },
    years_of_experience: { type: Type.NUMBER, description: "Total relevant years of experience extracted." },
    education_match: { type: Type.STRING, description: "Assessment of education qualifications (e.g., 'Matches', 'Exceeds', 'Below requirements')." },
    technical_skills_found: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List of technical skills found in the resume that match the job description."
    },
    soft_skills_found: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List of soft skills found in the resume."
    },
    missing_critical_skills: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "Critical skills required by the JD that are missing in the resume."
    },
    recommendation: { 
      type: Type.STRING, 
      enum: ["Strong Hire", "Hire", "Consider", "Reject"],
      description: "Final recommendation classification."
    }
  },
  required: ["candidate_name", "match_score", "summary", "years_of_experience", "education_match", "recommendation"]
};

/**
 * Analyzes a resume against a job description using Gemini 1.5 Flash.
 * @param jobDescriptionText The text of the job description.
 * @param fileBase64 The base64 string of the resume file.
 * @param mimeType The mime type of the resume file.
 */
export const analyzeResume = async (
  jobDescriptionText: string,
  fileBase64: string,
  mimeType: string
): Promise<AnalysisResult> => {
  
  try {
    const model = "gemini-2.5-flash";
    
    // Clean base64 string if it contains the data URL prefix
    const cleanBase64 = fileBase64.split(',')[1] || fileBase64;

    const response = await genAI.models.generateContent({
      model: model,
      contents: {
        role: "user",
        parts: [
          {
            text: `You are an expert HR AI Assistant. Your task is to screen a resume against a specific job description. 
            
            JOB DESCRIPTION:
            ${jobDescriptionText}
            
            Analyze the attached resume file. Extract the candidate's details and compare them strictly against the Job Description provided.
            Calculate a weighted match score based on Skills (40%), Experience (30%), and Education (30%).
            Be critical but fair. Return the result in JSON format.`
          },
          {
            inlineData: {
              mimeType: mimeType,
              data: cleanBase64
            }
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        temperature: 0.2 // Low temperature for consistent, analytical results
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text) as AnalysisResult;
      // Fallback for names if extraction fails or is generic
      if (!result.candidate_name || result.candidate_name === "Unknown") {
        result.candidate_name = "Candidate (Name Not Found)";
      }
      return result;
    } else {
      throw new Error("Empty response from AI model");
    }

  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw error;
  }
};